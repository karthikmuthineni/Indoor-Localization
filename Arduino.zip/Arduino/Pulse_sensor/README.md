# bluetooth-pulse-rate-sensor
Code for the Bluetooth Heart-Rate Sensor with Arduino project
